class Appointment < ActiveRecord::Base
	belongs_to :pet
end
