class Vet < ActiveRecord::Base
end
