module VetsHelper
end
