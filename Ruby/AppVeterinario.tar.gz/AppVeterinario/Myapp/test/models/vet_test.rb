require 'test_helper'

class VetTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
